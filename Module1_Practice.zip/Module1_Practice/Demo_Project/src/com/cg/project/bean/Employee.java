  package com.cg.project.bean;

public class Employee {

	private String name;
	private Address address;
	private int Id;
	
	public Employee()
	{
		super();
	}
	
	public Employee(String name, Address address, int Id) {
		super();
		this.name = name;
		this.address = address;
		this.Id = Id;
	}

	public String getEmpName() {
		return name;
	}

	public void setEmpName(String name) {
		this.name = name;
	}

	public Address getAddress() {
		return this.address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public int getEmpId() {
		return Id;
	}

	public void setEmpId(int Id) {
		this.Id = Id;
	}

	@Override
	public String toString() {
		return "Employee [empName=" + name + ", address=" + address + ", empId=" + Id + "]";
	}
	
	
	
}
