package com.cg.project.bean;

public class Address 
{
	 
	private String address;
	private Country country;
	
	public Address()
		{
		super();
		}
	
	public Address(String address, Country country) {
		super();
		this.address = address;
		this.country = country;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public Country getCountry() {
		return this.country;
	}
	public void setCountry(Country country) {
		this.country = country;
	}
	
	
	@Override
	public String toString() {
		return "Address [address=" + address + ", country=" + country + "]";
	}
	
	
	
}
