package com.cg.project.bean;

public class Country 
{
	 
	private String countryName;
	private City cityname;
	
	public Country()
	{
		super();
	}
	
	public Country(String countryName, City cityname) {
		super();
		this.countryName = countryName;
		this.cityname = cityname;
	}
	public String getCountryName() 
	{
		return countryName;
	}
	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}
	public City getCityname() {
		return this.cityname;
	}
	public void setCityname(City cityname) {
		this.cityname = cityname;
	}
	
	
	@Override
	public String toString() {
		return "Country [countryName=" + countryName + ", cityname=" + cityname + "]";
	}
	
}
