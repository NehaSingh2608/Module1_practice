package com.cg.project.Repo;

import java.util.Map;

import com.cg.project.bean.Employee;

public interface IRepository {

	boolean saveEmployee(Employee e); 
	public Map<Integer,Employee> findById(int id);
	
}
