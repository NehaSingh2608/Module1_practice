package com.cg.project.Repo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cg.project.bean.Address;
import com.cg.project.bean.Employee;
import com.cg.project.util.EmployeeDeatils;

public class Repository implements IRepository{
 Map<Integer,Employee> emp=new HashMap<>();
 private EmployeeDeatils ed;
	public Repository(EmployeeDeatils employeeDeatils) {
	// TODO Auto-generated constructor stub
		super();
		//this.ed=employeeDeatils;
}
	@Override
	public boolean saveEmployee(Employee e) {
		
		if(emp.containsKey(e.getEmpId()))
			return false;
		
		emp.put(e.getEmpId(), e);
		return true;
		
	}
@Override
	public Map<Integer, Employee> findById(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean addEmployee(String empName, Address address, int id) {
		return false;
		// TODO Auto-generated method stub
		/*if(validateId==true)
			emp.put(empName, address, id);
		return false;
	}
	public boolean validateId() {
		if(id==pattern)*/
}
}
