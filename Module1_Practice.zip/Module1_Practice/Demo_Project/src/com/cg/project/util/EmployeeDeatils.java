package com.cg.project.util;

import java.util.HashMap;
import java.util.Map;

import com.cg.project.bean.Employee;

public class EmployeeDeatils {
	static Employee e=new Employee();

	public  void DetailCollection() {
	
	   {
			Map<Integer, Employee> emp=new HashMap<>();
			emp.put(e.getEmpId(), e);

		}
		
	}

}
