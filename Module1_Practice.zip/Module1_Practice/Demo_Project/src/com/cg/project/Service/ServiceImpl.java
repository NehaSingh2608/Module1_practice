package com.cg.project.Service;

import java.util.Map;

import com.cg.project.Repo.Repository;
import com.cg.project.bean.Address;
import com.cg.project.bean.Employee;

public class ServiceImpl implements IService {
  private  Repository repo;
  Employee e=new Employee();
  
public ServiceImpl(Repository repository) {
	super();
	this.repo=repository;
}


@Override
public boolean addEmployee(String empName, Address address, int Id) {
	// TODO Auto-generated method stub
	if(repo.saveEmployee(e))
	     return true;
	else
		return false;
}


public Map<String, Employee> searchById(int id) {
	// TODO Auto-generated method stub
	repo.findById(e.getEmpId());
	return null;
}
  
  
  
  
  
  
  
  
  
}

	

