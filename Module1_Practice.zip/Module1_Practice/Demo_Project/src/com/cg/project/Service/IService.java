package com.cg.project.Service;

import java.util.Map;

import com.cg.project.bean.Address;
import com.cg.project.bean.Employee;

public interface IService {

  public  boolean addEmployee(String empName, Address address,int Id);
	Map<String, Employee> searchById(int id);
	
}
