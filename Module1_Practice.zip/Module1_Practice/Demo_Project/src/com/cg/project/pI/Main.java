package com.cg.project.pI;

import com.cg.project.Repo.Repository;
import com.cg.project.Service.IService;
import com.cg.project.Service.ServiceImpl;
import com.cg.project.util.EmployeeDeatils;

public class Main {

	public static void main(String[] args)
	{
		IService service=new ServiceImpl(new Repository(new EmployeeDeatils( )));
         	service
	}

}
