package test_demo;

public class Person {
 private String name;

public Person(String name) {
	super();
	this.name = name;
}
 
}
