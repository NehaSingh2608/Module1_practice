package test_demo;

import java.util.HashSet;
import java.util.Set;

public class TestCollection {

	public static void main(String[] args) {
		Set<Person> st=new HashSet<Person>();
		st.add(new Person("Renu"));
		st.add(new Person("Renu"));
		
		System.out.println(st.size());
	}

}
      